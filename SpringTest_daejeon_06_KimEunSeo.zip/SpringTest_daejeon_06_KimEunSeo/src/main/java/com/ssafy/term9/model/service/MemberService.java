package com.ssafy.term9.model.service;

import com.ssafy.term9.model.Member;

public interface MemberService {

	Member login(Member member) throws Exception;
}
